def _normalize_desc(desc):
    return (
        (desc or "")
        .strip()
        .lower()
        .replace("_", " ")
        .replace("-", " ")
    )


def _normalize_hex_bytes(payload):
    normalized = []
    for byte in payload or []:
        if isinstance(byte, int):
            normalized.append(f"{byte:02X}")
        elif isinstance(byte, str):
            normalized.append(byte.strip().upper())
    return [byte for byte in normalized if byte]


def decode_special_did_value(desc, payload):
    normalized_desc = _normalize_desc(desc)
    clean_payload = _normalize_hex_bytes(payload)

    if not clean_payload:
        return None

    if "b can" in normalized_desc and "version" in normalized_desc:
        # Keep the hex-digit/Bcd representation unchanged and add dots.
        return ".".join(clean_payload[:3]) if len(clean_payload) >= 3 else None

    if "manufacturing date" in normalized_desc and len(clean_payload) >= 4:
        year = f"{clean_payload[0]}{clean_payload[1]}"
        month = clean_payload[2]
        day = clean_payload[3]
        return f"{year}-{month}-{day}"

    return None
