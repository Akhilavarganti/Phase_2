import os
import re
import csv
import datetime
from collections import defaultdict
from html import escape
import logging
from drivers.Parse_handler import HEADER_ALIASES, find_column, load_testcases
from drivers.did_decoder import decode_special_did_value

DESCRIPTION_MAP = {}

def load_description_map(txt_file_path):
    desc_map = {}
    grouped_cases = load_testcases(txt_file_path)
    for steps in grouped_cases.values():
        for step in steps:
            if not step or step[0] == "WAIT":
                continue

            (
                tc_id,
                description,
                sid,
                sub,
                expected_response_data,
                _write_data,
                _addressing,
                format_type,
                *_rest,
            ) = step

            sid = sid.strip().replace("0x", "").upper()
            sub = sub.strip().replace("0x", "").upper()
            expected_bytes = [
                b.replace("0x", "").upper()
                for b in expected_response_data.split()
                if b
            ]
            key = (sid, sub)
            value = (description.strip(), tc_id.strip(), expected_bytes, (format_type or "Hex").strip().capitalize())
            if key not in desc_map:
                desc_map[key] = []
            desc_map[key].append(value)
    return desc_map


def parse_data_bytes(line, ctype):
    try:
        parts = line.strip().split()

        if ctype == "CANFD":
            candidate_start = None
            candidate_len = 0

            for idx in range(len(parts) - 2):
                if not parts[idx].isdigit() or not parts[idx + 1].isdigit():
                    continue

                possible_len = int(parts[idx + 1])
                if possible_len <= 0 or possible_len > 64:
                    continue

                next_tokens = parts[idx + 2: idx + 2 + possible_len]
                if len(next_tokens) != possible_len:
                    continue

                if all(re.fullmatch(r"[0-9A-Fa-f]{2}", token) for token in next_tokens):
                    candidate_start = idx + 2
                    candidate_len = possible_len
                    break

            if candidate_start is not None:
                return [
                    value.upper()
                    for value in parts[candidate_start: candidate_start + candidate_len]
                ]

        for idx, token in enumerate(parts):
            if token == "d" and idx + 1 < len(parts):
                try:
                    dlc = int(parts[idx + 1])
                except ValueError:
                    continue

                payload = []
                for value in parts[idx + 2:]:
                    if re.fullmatch(r"[0-9A-Fa-f]{2}", value):
                        payload.append(value.upper())
                    elif payload:
                        break

                if payload:
                    return payload[:dlc]

        match = re.search(r"((?:\b[0-9A-Fa-f]{2}\b(?:\s+|$))+)$", line.strip())
        if match:
            return [byte.upper() for byte in match.group(1).split()]
    except Exception:
        pass
    return []




def get_description(data_bytes):
    if not data_bytes or len(data_bytes) < 1:
        return "", "", "", ""
    
    # Known UDS SIDs — extend as needed
    known_sids = {"10", "11", "22", "2E", "19", "27", "28","2F", "3E", "31", "14", "85"}
    sid_index = -1
    sid = ""
    for i, byte in enumerate(data_bytes):
        if byte.upper() in known_sids:
            sid_index = i
            sid = byte.upper()
            break

    if sid_index == -1:
        return "", "", "", ""

    # Try matching with subfunction (3, 2, or 1 bytes)
# Try all possible subfunction/DID lengths
    for length in (3, 2, 1, 0):  # Added 0 to handle cases with only SID
        if sid_index + length < len(data_bytes):
            sub = ''.join(data_bytes[sid_index + 1: sid_index + 1 + length]).upper() if length > 0 else ""
            key = (sid, sub)
            if key in DESCRIPTION_MAP:
                used = getattr(get_description, "used_tc_ids", set())
                for desc, tc_id, expected_resp, fmt in DESCRIPTION_MAP[key]:
                    if tc_id not in used:
                        used.add(tc_id)
                        setattr(get_description, "used_tc_ids", used)
                        return desc, tc_id, expected_resp, fmt
                return DESCRIPTION_MAP[key][0]

    # Try fallback: SID only
    key = (sid, "")
    if key in DESCRIPTION_MAP:
        used = getattr(get_description, "used_tc_ids", set())
        for desc, tc_id, expected_resp in DESCRIPTION_MAP[key]:
            if tc_id not in used:
                used.add(tc_id)
                setattr(get_description, "used_tc_ids", used)
                return desc, tc_id, expected_resp
        return DESCRIPTION_MAP[key][0]

    return "", "", "", ""





def get_failure_reason(nrc):
    reasons = {
        "10" : "generalReject",
        "11" : "serviceNotSupported",
        "12" : "subFunctionNotSupported",
        "13" : "incorrectMessageLengthOrInvalidFormat",
        "14" : "responseTooLong",
        "21" : "busyRepeatReques",
        "22" : "conditionsNotCorrect",
        "23" : "ISOSAEReserved",
        "24" : "requestSequenceError",
        "31" : "requestOutOfRange",
        "32" : "ISOSAEReserved",
        "33" : "securityAccessDenied",
        "34" : "ISOSAEReserved",
        "35" : "invalidKey",
        "36" : "exceedNumberOfAttempts",
        "37" : "requiredTimeDelayNotExpired",
        "70" : "uploadDownloadNotAccepted",
        "71" : "transferDataSuspended",
        "72" : "generalProgrammingFailure",
        "73" : "wrongBlockSequenceCounter",
        "78" : "requestCorrectlyReceived-ResponsePending",
        "7E" : "subFunctionNotSupportedInActiveSession",
        "7F" : "serviceNotSupportedInActiveSession",
        "80" : "ISOSAEReserved",
        "81" : "rpmTooHigh",
        "82" : "rpmTooLow",
        "83" : "engineIsRunning",
        "84" : "engineIsNotRunning",
        "85" : "engineRunTimeTooLow",
        "86" : "temperatureTooHigh",
        "87" : "temperatureTooLow",
        "88" : "vehicleSpeedTooHigh",
        "89" : "vehicleSpeedTooLow",
        "8A" : "throttle/PedalTooHigh",
        "8B" : "throttle/PedalTooLow",
        "8C" : "transmissionRangeNotInNeutral",
        "8D" : "transmissionRangeNotInGear",
        "8E" : "ISOSAEReserved",
        "8F" : "brakeSwitch(es)NotClosed (Brake Pedal not pressed or not applied)",
        "90" : "shifterLeverNotInPark",
        "91" : "torqueConverterClutchLocked",
        "92" : "voltageTooHigh",
        "93" : "voltageTooLow",
        "FF" : "ISOSAEReserved",
    }
    return reasons.get(nrc.upper(), f"Unknown NRC: {nrc}")


def normalize_hex_bytes(data_bytes):
    return [b.strip().upper() for b in data_bytes if isinstance(b, str)]


def extract_isotp_payload(data_bytes):
    data = normalize_hex_bytes(data_bytes)
    if not data:
        return []

    try:
        pci = int(data[0], 16)
    except ValueError:
        return data

    frame_type = (pci >> 4) & 0x0F

    if frame_type == 0:
        payload_len = pci & 0x0F
        return data[1:1 + payload_len]

    if frame_type == 1 and len(data) >= 2:
        payload_len = ((pci & 0x0F) << 8) | int(data[1], 16)
        return data[2:2 + payload_len]

    return data


def normalize_for_compare(data_bytes):
    raw = remove_trailing_padding(
        remove_trailing_padding(normalize_hex_bytes(data_bytes), "00"),
        "AA",
    )
    payload = remove_trailing_padding(
        remove_trailing_padding(extract_isotp_payload(raw), "00"),
        "AA",
    )
    return raw, payload

def get_status(actual_data, expected_response_data):
    """
    Determines Pass/Fail by comparing full actual vs expected response.
    Handles negative responses with NRCs too.
    """
    if not actual_data:
        return "Fail", "No response received"
    if not expected_response_data:
        return "Fail", "Expected response not specified"

    actual_raw, actual_payload = normalize_for_compare(actual_data)
    expected_raw, expected_payload = normalize_for_compare(expected_response_data)

    if (
        actual_raw == expected_raw
        or actual_payload == expected_payload
        or actual_payload == expected_raw
        or actual_raw == expected_payload
    ):
        return "Pass", ""

    # 🟥 Negative Response Handling
    if len(actual_payload) >= 3 and actual_payload[0] == "7F":
        nrc = actual_payload[2]
        return "Fail", f"Negative Response (0x{nrc}: {get_failure_reason(nrc)})"

    return "Fail", "Response mismatch"


def parse_line(line):
    line = line.strip()
    if not line:
        return None

    timestamp_match = re.match(r"^(?P<timestamp>\d+\.\d+)", line)
    if not timestamp_match:
        return None

    parts = line.split()
    timestamp = float(timestamp_match.group("timestamp"))

    if "errorframe" in line.lower():
        direction = "Tx" if "Tx" in parts else "Rx" if "Rx" in parts else ""
        return {
            "timestamp": timestamp,
            "can_id": "ERROR",
            "direction": direction,
            "data_bytes": [],
            "raw": line,
            "frame_kind": "error",
        }

    if "CANFD" not in line and " d " not in line:
        return None

    try:
        direction_idx = next(
            idx for idx, token in enumerate(parts) if token in ("Tx", "Rx")
        )
    except StopIteration:
        return None

    direction = parts[direction_idx]
    ctype = "CANFD" if "CANFD" in line else "CAN"
    can_id = None

    for idx in (direction_idx - 1, direction_idx + 1, direction_idx - 2, direction_idx + 2):
        if 0 <= idx < len(parts) and re.fullmatch(r"[0-9A-Fa-f]{3,8}", parts[idx]):
            can_id = parts[idx].upper()
            break

    if can_id is None:
        return None

    return {
        "timestamp": timestamp,
        "can_id": can_id,
        "direction": direction,
        "data_bytes": parse_data_bytes(line, ctype),
        "raw": line,
        "frame_kind": "message",
    }



def parse_asc_file(asc_file_path, allowed_tx_ids, allowed_rx_ids):
    messages_by_tc = defaultdict(list)
    current_request = None
    pending_first_frame = None
    assembling_request = False
    request_buffer = []
    total_req_len = 0

    awaiting_response = False
    response_buffer = []
    total_resp_len = 0
    collected_len = 0
    skip_next_fc = False
    pending_flag = False
    pending_error_frame = None

    start_ts, end_ts = None, None
    base_datetime = None

    def finalize_request(failure_reason, response=None, response_data_bytes=None, response_type=None):
        nonlocal current_request, start_ts, end_ts
        if not current_request:
            return

        current_request.update({
            "response": response or {},
            "response_data_bytes": response_data_bytes or [],
            "status": "Fail",
            "failure_reason": failure_reason,
            "response_type": response_type or "Response Received",
        })
        messages_by_tc[current_request["tc_id"]].append(current_request)
        start_ts = min(start_ts or current_request["timestamp"], current_request["timestamp"])
        response_ts = (
            response.get("timestamp")
            if response and isinstance(response.get("timestamp"), (int, float))
            else current_request["timestamp"]
        )
        end_ts = max(end_ts or response_ts, response_ts)
        current_request = None



    allowed_tx_ids = set(f"{id:X}" for id in allowed_tx_ids)
    allowed_rx_ids = set(f"{id:X}" for id in allowed_rx_ids)
    
    ALLOWED_IDS = allowed_tx_ids | allowed_rx_ids
    
    with open(asc_file_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    for i, line in enumerate(lines):
        if line.startswith("Begin Triggerblock"):
            try:
                date_str = line.strip().replace("Begin Triggerblock ", "")
                base_datetime = datetime.datetime.strptime(date_str, "%a %b %d %I:%M:%S.%f %p %Y")
            except ValueError:
                base_datetime = None
            break

    for line in lines:
        line = line.strip()
        if not line or not re.match(r"^\d+\.\d+", line):
            continue

        msg = parse_line(line)
        if not msg:
            continue

        if msg["frame_kind"] == "error":
            if current_request:
                pending_error_frame = msg
            continue

        if msg["can_id"] not in ALLOWED_IDS:
            continue

        can_id = msg["can_id"]
        direction = msg["direction"]
        data = msg["data_bytes"]

        if not data:
            if direction == "Rx" and current_request:
                finalize_request(
                    "Received frame without payload",
                    response=msg,
                    response_data_bytes=[],
                    response_type="Empty Frame",
                )
                awaiting_response = False
                response_buffer = []
                pending_flag = False
                pending_error_frame = None
            continue
        
        # 🟦 Tx: Handle Request
        if direction == "Tx" and can_id in allowed_tx_ids:
            pci_type = data[0].upper()

            # Tester flow-control frames belong to the active ISO-TP response
            # transfer and must not be treated as a new diagnostic request.
            if current_request and awaiting_response and pci_type == "30":
                continue

            if current_request:
                failure_reason = (
                    "Incomplete multi-frame response"
                    if awaiting_response or response_buffer
                    else "No response received"
                )
                response = None
                response_type = "No Response"
                if pending_error_frame:
                    failure_reason = "CAN error frame detected before response"
                    response = pending_error_frame
                    response_type = "Error Frame"
                finalize_request(
                    failure_reason,
                    response=response,
                    response_data_bytes=response_buffer[:],
                    response_type=response_type,
                )
                awaiting_response = False
                response_buffer = []
                pending_flag = False
                pending_error_frame = None

            if pci_type == "10":  # First Frame of Multi-Frame Request
                assembling_request = True
                total_req_len = ((int(data[0], 16) & 0x0F) << 8) | int(data[1], 16)
                request_buffer = data[2:]
                pending_first_frame = msg
                skip_next_fc = True
                continue

            elif skip_next_fc and pci_type == "30":
                skip_next_fc = False
                continue

            elif assembling_request and pci_type.startswith("2"):  # Consecutive Frame
                request_buffer += data[1:]
                if len(request_buffer) >= total_req_len:
                    trimmed_data = request_buffer[:total_req_len]
                    desc, tc_id, expected_resp, fmt = get_description(trimmed_data)
                    if desc and tc_id:
                        current_request = {
                            "timestamp": pending_first_frame["timestamp"],
                            "can_id": pending_first_frame["can_id"],
                            "direction": "Tx",
                            "data_bytes": trimmed_data,
                            "desc": desc,
                            "tc_id": tc_id,
                            "format": fmt,
                            "expected_resp": expected_resp,
                            "status": "Pending"
                        }
                    assembling_request = False
                    request_buffer = []
                    pending_first_frame = None
                continue

            else:  # Single-Frame Request
                desc, tc_id, expected_resp, fmt = get_description(data)
                if desc and tc_id:
                    current_request = {
                        "timestamp": msg["timestamp"],
                        "can_id": can_id,
                        "direction": direction,
                        "data_bytes": data,
                        "desc": desc,
                        "tc_id": tc_id,
                        "format": fmt,
                        "expected_resp": expected_resp,
                        "status": "Pending"
                    }

        # ◀️ Rx: Handle Response
        elif direction == "Rx" and can_id in allowed_rx_ids and current_request:
            pci_type = data[0].upper()

            if pci_type == "30":
                continue  # Ignore flow control

            # Handle 0x7F xx 78 pending response
            if len(data) >= 4 and data[1].upper() == "7F" and data[3].upper() == "78":
                pending_flag = True
                continue  # Ignore pending response

            if pending_flag:
                pending_flag = False
                full_resp = data  # Treat next frame as actual response
            else:
                if pci_type == "10":  # First frame of multi-frame response
                    total_resp_len = ((int(data[0], 16) & 0x0F) << 8) | int(data[1], 16)
                    response_buffer = data[2:]  # payload only
                    collected_len = len(response_buffer)
                    awaiting_response = True
                    continue

                elif pci_type.startswith("2") and awaiting_response:
                    response_buffer += data[1:]  # payload only
                    collected_len += len(data) - 1
                    if collected_len >= total_resp_len:
                        full_resp = response_buffer[:total_resp_len]
                        awaiting_response = False
                    else:
                        continue
                elif pci_type.startswith("2") and not awaiting_response:
                    # Orphan consecutive frame from a previously interrupted
                    # multi-frame transfer. Do not mis-attach it to the next
                    # testcase request.
                    logging.warning(
                        f"Ignoring orphan consecutive frame for active request {current_request['tc_id']}: {msg['raw']}"
                    )
                    continue
                else:
                    if awaiting_response:
                        response_buffer += data[1:]
                        full_resp = response_buffer[:total_resp_len]
                        awaiting_response = False
                    else:
                        full_resp = data

            # ✅ Evaluate response
            status, reason = get_status(full_resp, current_request["expected_resp"])
            current_request.update({
                "response": msg,
                "response_data_bytes": full_resp,
                "status": status,
                "failure_reason": reason,
                "response_type": "Response Received",
            })

            messages_by_tc[current_request["tc_id"]].append(current_request)

            # Update timestamps
            start_ts = min(start_ts or msg["timestamp"], current_request["timestamp"])
            end_ts = max(end_ts or msg["timestamp"], msg["timestamp"])

            current_request = None
            response_buffer = []
            pending_error_frame = None

    if current_request:
        failure_reason = (
            "Incomplete multi-frame response"
            if awaiting_response or response_buffer
            else "No response received"
        )
        response = None
        response_type = "No Response"
        if pending_error_frame:
            failure_reason = "CAN error frame detected before response"
            response = pending_error_frame
            response_type = "Error Frame"
        finalize_request(
            failure_reason,
            response=response,
            response_data_bytes=response_buffer[:],
            response_type=response_type,
        )

    return messages_by_tc, start_ts or 0, end_ts or 0, base_datetime

# stage.............

import datetime
from html import escape

def flatten_bytes(data):
    flat = []
    for item in data:
        if isinstance(item, list):
            
            flat.extend(item)
        else:
            flat.append(item)
    return flat

def remove_trailing_padding(data_list, pad_byte):
    # Remove only trailing occurrences of pad_byte (like "00" or "AA")
    i = len(data_list)
    while i > 0 and data_list[i - 1].upper() == pad_byte.upper():
        i -= 1
    return data_list[:i]

def get_valid_request_data(data_bytes):
    """
    Extracts the actual data from a UDS request.
    Assumes the first byte is the PCI, which tells us how many bytes follow.
    """
    
    if not data_bytes:
        return data_bytes
    try:
        pci = int(data_bytes[0], 16)
        if pci <= 0x07:
            # Single-frame: first byte is length of remaining data
            total_len = pci + 1  # include PCI itself
            return data_bytes[:total_len]
    except:
        pass
    return data_bytes


def get_expected_ecu_info_fields(txt_file_path):
    fields = []
    seen = set()
    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            header = None
            for row in reader:
                if not row:
                    continue
                first_col = row[0].strip()
                if first_col.startswith("#Author") or first_col.startswith("#Date"):
                    continue
                if first_col.startswith("#TC_ID") or first_col.startswith("TC_ID"):
                    header = [h.strip().lstrip("#") for h in row]
                    break

            if header is None:
                return fields

            col = {name: idx for idx, name in enumerate(header)}
            tc_id_idx = find_column(col, HEADER_ALIASES["TC_ID"])
            desc_idx = find_column(col, HEADER_ALIASES["DESCRIPTION"])

            for row in reader:
                if not row or len(row) <= max(tc_id_idx, desc_idx):
                    continue
                tc_id = row[tc_id_idx].strip()
                desc = row[desc_idx].strip()
                if tc_id.startswith("ECU_INFO") and desc and desc not in seen:
                    seen.add(desc)
                    fields.append(desc)
    except Exception as exc:
        logging.warning(f"Failed to derive ECU info field list from testcase file: {exc}")

    return fields


def get_testcase_author(txt_file_path):
    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if not row:
                    continue
                first_col = row[0].strip()
                if first_col.startswith("#Author"):
                    if len(row) > 1 and row[1].strip():
                        return row[1].strip()
                    if ":" in first_col:
                        return first_col.split(":", 1)[1].strip()
                    return "N/A"
                if first_col.startswith("#TC_ID") or first_col.startswith("TC_ID"):
                    break
    except Exception as exc:
        logging.warning(f"Failed to read testcase author from header: {exc}")

    return "N/A"


def get_testcase_generated_metadata(txt_file_path):
    metadata = {
        "filename": os.path.basename(txt_file_path),
        "generated_at": None,
    }

    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if not row:
                    continue

                first_col = row[0].strip()
                second_col = row[1].strip() if len(row) > 1 else ""

                if first_col.startswith("#TC_ID") or first_col.startswith("TC_ID"):
                    break

                normalized_key = first_col.lstrip("#").strip().lower()
                if first_col.startswith("#Date") or normalized_key in {"date", "generated", "generated on"}:
                    date_value = ""
                    time_value = ""

                    if ":" in first_col:
                        date_value = first_col.split(":", 1)[1].strip()
                    if second_col:
                        second_col_clean = second_col.strip()
                        if second_col_clean.lower().startswith("time"):
                            time_value = second_col_clean.split(":", 1)[1].strip()
                        else:
                            time_value = second_col_clean

                    combined = f"{date_value} {time_value}".strip()
                    metadata["generated_at"] = combined or metadata["generated_at"]
                elif normalized_key in {"file", "filename", "input file"} and second_col:
                    metadata["filename"] = os.path.basename(second_col)
    except Exception as exc:
        logging.warning(f"Failed to read testcase generated metadata from header: {exc}")

    return metadata


def format_generated_entry(filename, generated_at):
    safe_filename = os.path.basename(filename) if filename else "N/A"
    safe_generated_at = generated_at or "N/A"
    return f"{safe_filename} {safe_generated_at}"


def get_file_generated_time(file_path):
    try:
        timestamp = os.path.getmtime(file_path)
        return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
    except Exception as exc:
        logging.warning(f"Failed to read file timestamp for {file_path}: {exc}")
        return "N/A"

# stage.............

def generate_html_report(messages_by_tc, output_path, asc_file_path, start_ts, end_ts, ecu_info_data=None, target_ecu=None, base_datetime=None, expected_ecu_fields=None, author_name="N/A", input_file_metadata=None):
    def remove_padding(data_list, pad_byte):
        return [byte for byte in data_list if byte.upper() != pad_byte.upper()]

    def format_response_value(raw_resp, format_type, desc=""):
        clean_resp_t = remove_trailing_padding(raw_resp or [], "00")
        clean_resp = remove_trailing_padding(clean_resp_t, "AA")
        payload_bytes = extract_isotp_payload(clean_resp)
        format_type = (format_type or "Hex").strip().lower()

        try:
            full_hex_str = " ".join(clean_resp)
            payload = payload_bytes

            if "62" in [b.upper() for b in payload]:
                idx = next(i for i, b in enumerate(payload) if b.upper() == "62")
                payload = payload[idx + 3:] if len(payload) > idx + 2 else []

            special_value = decode_special_did_value(desc, payload)
            if special_value:
                return special_value

            if format_type == "ascii":
                if payload and all(32 <= int(b, 16) <= 126 for b in payload):
                    return "".join(chr(int(b, 16)) for b in payload)
                return full_hex_str

            if format_type == "decimal":
                if payload:
                    return " ".join(str(int(b, 16)) for b in payload)
                return full_hex_str

            return full_hex_str
        except Exception:
            return " ".join(clean_resp)

    def build_ecu_info_from_messages():
        parsed = {}
        for steps in messages_by_tc.values():
            for msg in steps:
                tc_id = msg.get("tc_id", "")
                desc = msg.get("desc", "")
                if not tc_id.startswith("ECU_INFO") or not desc:
                    continue

                response_type = msg.get("response_type", "Response Received")
                raw_resp = msg.get(
                    "response_data_bytes",
                    msg.get("response", {}).get("data_bytes", []),
                )

                if raw_resp:
                    parsed[desc] = format_response_value(
                        raw_resp,
                        msg.get("format", "Hex"),
                        desc,
                    )
                elif response_type == "No Response":
                    parsed.setdefault(desc, "ECU No response")
        return parsed

    total = len(messages_by_tc)
    passed = sum(1 for tc in messages_by_tc.values() if all(msg["status"] == "Pass" for msg in tc))
    failed = total - passed
    duration = end_ts - start_ts
    html_generated_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    asc_filename = os.path.basename(asc_file_path)
    html_filename = os.path.basename(output_path)
    input_filename = (
        input_file_metadata.get("filename")
        if input_file_metadata
        else "N/A"
    )
    input_generated_time = (
        input_file_metadata.get("generated_at")
        if input_file_metadata
        else "N/A"
    )
    asc_generated_time = get_file_generated_time(asc_file_path)

    parsed_ecu_info_data = build_ecu_info_from_messages()
    ecu_info_data = ecu_info_data or {}
    merged_ecu_info = dict(ecu_info_data)
    for field, value in parsed_ecu_info_data.items():
        if value:
            merged_ecu_info[field] = value
    ecu_info_lines = []
    if expected_ecu_fields:
        for field in expected_ecu_fields:
            value = merged_ecu_info.get(field) or "ECU No response"
            ecu_info_lines.append(
                f"<p><strong>{escape(field)}:</strong> {escape(value)}</p>"
            )
    else:
        ecu_info_lines = [
            f"<p><strong>{escape(k)}:</strong> {escape(v)}</p>"
            for k, v in merged_ecu_info.items()
        ]
        
    html = f"""<!DOCTYPE html>
<html>
<head><title>UDS Diagnostic Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  body {{ font-family: Arial; margin: 20px; }}
  .pass {{ color: green; font-weight: bold; }}
  .fail {{ color: red; font-weight: bold; }}
  .chart-filter-row {{
    display: flex;
    align-items: center;
    gap: 18px;
    margin-top: 12px;
    margin-left: 24px;
    font-size: 14px;
  }}
  .chart-filter-item {{
    display: inline-flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    user-select: none;
  }}
  .chart-filter-swatch {{
    width: 28px;
    height: 12px;
    display: inline-block;
  }}
  .chart-filter-label.inactive {{
    text-decoration: line-through;
    opacity: 0.6;
  }}
  .wrapper {{
    display: flex;
    justify-content: center;
    align-items: flex-start;
    gap: 50px;
    margin-top: 20px;
  }}
  .summary-block {{ text-align: left; min-width: 250px; }}
  #chart-container {{ width: 300px; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
  th, td {{ border: 1px solid #ccc; padding: 8px; }}
  th {{ background: #f0f0f0; }}
  summary {{ font-weight: bold; cursor: pointer; }}
</style>
</head>
<body>

<h1 style="text-align: center;">UDS Diagnostic Report</h1>

<div style="display: flex; justify-content: flex-start; align-items: flex-start; gap: 40px; margin-top: 20px; padding-left: 10px;">
    <div style="width: 650px;">
    
        {f"<p><strong>Target ECU:</strong> {escape(target_ecu)}</p>" if target_ecu else ""}
        {"".join(ecu_info_lines)}
        
        <hr style="width: 300px;border:1px solid #999; margin:25px 0;">
        
        <p><strong>Input File (Generated):</strong> {escape(format_generated_entry(input_filename, input_generated_time))}</p>
        <p><strong>HTML Report (Generated):</strong> {escape(format_generated_entry(html_filename, html_generated_time))}</p>
        <p><strong>ASC Report (Generated):</strong> {escape(format_generated_entry(asc_filename, asc_generated_time))}</p>
        <p><strong>Total Test Cases:</strong> {total}</p>
        <p class="pass"><strong>Passed:</strong> {passed}</p>
        <p class="fail"><strong>Failed:</strong> {failed}</p>
        <p><strong>Test Duration:</strong> {duration:.3f} seconds</p>
        <p><strong>Author:</strong> {escape(author_name)}</p>
        
    </div>
    <button type="button" onclick="showAllCases()">Show All</button>
    <div id="chart-container" style="width: 320px; margin-left:70px;">
        <canvas id="passFailChart" width="300" height="300"></canvas>
        <div class="chart-filter-row">
            <span class="chart-filter-item" onclick="setChartFilter('Passed')">
                <span class="chart-filter-swatch" style="background:#4CAF50;"></span>
                <span id="passedFilterLabel" class="chart-filter-label">Passed</span>
            </span>
            <span class="chart-filter-item" onclick="setChartFilter('Failed')">
                <span class="chart-filter-swatch" style="background:#F44336;"></span>
                <span id="failedFilterLabel" class="chart-filter-label">Failed</span>
            </span>
        </div>
    </div>
</div>

    <script>
        let activeFilter = null;

        function updateFilterLabels() {{
            const passedLabel = document.getElementById('passedFilterLabel');
            const failedLabel = document.getElementById('failedFilterLabel');

            passedLabel.classList.toggle('inactive', activeFilter === 'Failed');
            failedLabel.classList.toggle('inactive', activeFilter === 'Passed');
        }}

        function setChartFilter(label) {{
            activeFilter = label;
            filterCasesByLabel(label);
            updateFilterLabels();
            const filterIndex = chart.data.labels.indexOf(label);
            if (filterIndex >= 0) {{
                chart.setActiveElements([{{ datasetIndex: 0, index: filterIndex }}]);
            }}
            chart.update();
        }}

        function showAllCases() {{
            activeFilter = null;
            document.querySelectorAll('.case-block').forEach(el => {{
                el.style.display = 'block';
            }});
            chart.setActiveElements([]);
            updateFilterLabels();
            chart.update();
        }}

        function filterCasesByLabel(label) {{
            document.querySelectorAll('.case-block').forEach(el => {{
                el.style.display = 'none';
            }});
            if (label === 'Passed') {{
                document.querySelectorAll('.pass-case').forEach(el => {{
                    el.style.display = 'block';
                }});
            }} else if (label === 'Failed') {{
                document.querySelectorAll('.fail-case').forEach(el => {{
                    el.style.display = 'block';
                }});
            }}
        }}

        const ctx = document.getElementById('passFailChart').getContext('2d');
        const chart = new Chart(ctx, {{
            type: 'pie',
            data: {{
                labels: ['Passed', 'Failed'],
                datasets: [{{
                    data: [{passed}, {failed}],
                    backgroundColor: ['#4CAF50', '#F44336']
                }}]
            }},
            options: {{
                responsive: true,
                onClick: function (evt, item) {{
                    const segment = chart.getElementsAtEventForMode(evt, 'nearest', {{ intersect: true }}, true);
                    if (!segment.length) return;
                    const label = chart.data.labels[segment[0].index];
                    setChartFilter(label);
                }},
                plugins: {{
                    legend: {{ display: false }},
                    title: {{ display: true, text: 'Test Case Results' }}
                }}
            }}
        }});

        updateFilterLabels();
    </script>

    <hr><br>
    """

    for tc_id, steps in messages_by_tc.items():
        status = steps[0]['status']
        status_class = 'pass' if status == 'Pass' else 'fail' if status == 'Fail' else 'pending'
        html += f"<div class='case-block {status_class}-case'>\n"
        html += f"<details><summary>{tc_id} - <span class='{status_class}'>{status}</span></summary>\n"
        html += """<table><tr><th>Step</th><th>Description</th><th>Timestamp</th><th>Type</th><th>Data</th><th>Status</th><th>Failure Reason</th></tr>\n"""
        
        step_count = 1
        for msg in steps:
            desc = msg['desc']
            combined_desc = ""

            if "PreCondition:" in desc and "Testcase" in desc:
                parts = desc.split("PreCondition:", 1)[1].split("Testcase", 1)
                pre_detail = parts[0].strip()
                tc_detail = parts[1].strip()
                combined_desc = f"<b>PreCondition:</b> {escape(pre_detail)}<br><b>Testcase:</b>{escape(tc_detail)}"
            elif "PreCondition:" in desc:
                pre_detail = desc.split("PreCondition:", 1)[1].strip()
                combined_desc = f"<b>PreCondition:</b> {escape(pre_detail)}"
            else:
                combined_desc = escape(desc.strip())
            
            req_bytes = remove_trailing_padding(msg.get('data_bytes', []), "00")
            req_data = get_valid_request_data(msg.get('data_bytes', []))
            req_data_str = ' '.join(flatten_bytes(req_data))

            Expected_resp= msg.get('expected_resp', [])
            # Remove padding (AA and 00) from expected response
            E_clean_resp_t = remove_trailing_padding(Expected_resp, "00")
            E_clean_resp = remove_trailing_padding(E_clean_resp_t, "AA")
            Expected_resp_str = ' '.join(flatten_bytes(E_clean_resp))
            
            html += f"<tr><td>{step_count}</td><td>{escape(msg['desc'])}</td><td>{msg['timestamp']:.6f}</td><td>Request Sent</td><td>{req_data_str}</td><td></td><td>-</td></tr>\n"
            step_count += 1
            html += f"<tr><td>{step_count}</td><td></td><td></td><td>Expected_data</td><td>{Expected_resp_str}</td><td></td><td>-</td></tr>\n"
            step_count += 1

            response = msg.get("response", {})
            raw_resp = msg.get("response_data_bytes", response.get("data_bytes", []))
            # Remove padding (AA and 00) from response
            clean_resp_t = remove_trailing_padding(raw_resp, "00")
            clean_resp = remove_trailing_padding(clean_resp_t, "AA")
            payload_bytes = extract_isotp_payload(clean_resp)
            format_type = msg.get("format", "Hex").strip().lower()
            response_type = msg.get("response_type", "Response Received")
            try:
                full_hex_str = ' '.join(clean_resp)
                payload = payload_bytes

                # Locate positive response SID in the UDS payload and skip SID + DID
                if "62" in [b.upper() for b in payload]:
                    idx = next(i for i, b in enumerate(payload) if b.upper() == "62")
                    if len(payload) > idx + 2:
                        payload = payload[idx + 3:]
                    else:
                        payload = []
                else:
                    payload = payload

                special_value = decode_special_did_value(msg.get("desc", ""), payload)

                # Format conversion
                if special_value:
                    response_data_str = f"{full_hex_str} → {special_value}"

                elif format_type == "ascii":
                    ascii_str = ""
                    if payload and all(32 <= int(b, 16) <= 126 for b in payload):
                        ascii_str = ''.join(chr(int(b, 16)) for b in payload)
                    response_data_str = f"{full_hex_str} → {ascii_str}" if ascii_str else full_hex_str

                elif format_type == "decimal":
                    decimal_str = ' '.join(str(int(b, 16)) for b in payload)
                    response_data_str = f"{full_hex_str} → {decimal_str}" if decimal_str else full_hex_str

                else:  # default hex
                    response_data_str = full_hex_str

            except Exception:
                response_data_str = ' '.join(clean_resp)

            if response_type == "No Response":
                response_data_str = "ECU No response"
            elif response_type in ("Error Frame", "Empty Frame"):
                response_data_str = escape(response.get("raw", response_type))

            response_ts = response.get("timestamp")
            response_ts_str = f"{response_ts:.6f}" if isinstance(response_ts, (int, float)) else "-"
            html += f"<tr><td>{step_count}</td><td></td><td>{response_ts_str}</td><td>{escape(response_type)}</td><td>{response_data_str}</td><td>{msg['status']}</td><td>{escape(msg.get('failure_reason', ''))}</td></tr>\n"
            step_count += 1
        
        html += "</table></details></div>\n"

    html += "</body></html>"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"UDS HTML Report generated at:\n{output_path}\n")

def generate_report(asc_file_path, txt_file_path, output_html_file, allowed_tx_ids, allowed_rx_ids, ecu_info_data=None, target_ecu=None):
    global DESCRIPTION_MAP
    DESCRIPTION_MAP = load_description_map(txt_file_path)
    get_description.used_tc_ids = set()
    expected_ecu_fields = get_expected_ecu_info_fields(txt_file_path)
    author_name = get_testcase_author(txt_file_path)
    input_file_metadata = get_testcase_generated_metadata(txt_file_path)

    messages_by_tc, start_ts, end_ts, base_datetime = parse_asc_file(
        asc_file_path, allowed_tx_ids, allowed_rx_ids
    )

    report_path = output_html_file

    generate_html_report(
        messages_by_tc,
        report_path,
        asc_file_path,
        start_ts,
        end_ts,
        ecu_info_data,
        target_ecu,
        base_datetime,
        expected_ecu_fields,
        author_name,
        input_file_metadata
    )
