# DTP-CAN Software Architecture Document

## 1. Document Information

- Project: DTP-CAN
- Document Type: Software Architecture Document
- Date: 2026-07-28
- Codebase Reference: `D:\temp\DTP-CAN\DTP_code`
- Primary Runtime: Python application running on Raspberry Pi based DTP-CAN unit

## 2. Purpose

This document describes the software architecture of the DTP-CAN project based on the current Python implementation and the supplied system illustration. It explains the major software components, deployment structure, data flow, runtime behavior, external interfaces, and architectural decisions used to execute UDS-based diagnostic testcases over CAN/CAN FD and generate result artifacts.

## 3. Scope

This document covers:

- The Python application running on the DTP-CAN hardware unit
- Hardware-facing modules used by the application
- Git-based testcase and result synchronization
- UDS execution and CAN logging
- ASC and HTML report generation
- External system interactions shown in the reference illustration

This document does not define:

- Detailed testcase content
- Detailed ECU diagnostic specifications
- Full Test Hub web application internals
- Full cybersecurity or compliance design

## 4. Architectural Summary

The implemented solution consists of two cooperating applications:

1. DTP-CAN device application
   - Python application running on the Raspberry Pi based diagnostic unit
   - Executes UDS testcases over CAN/CAN FD
   - Generates ASC and HTML result artifacts

2. DiagTestPi Test Hub application
   - Node.js and Express web application
   - Manages testcase master data
   - Exports testcase bundles to the repository worktree
   - Publishes testcase and config files to Bitbucket
   - Reads generated result artifacts back from the repository worktree
   - Provides repository browsing, result browsing, and analytics

Together, these two applications form the end-to-end DTP-CAN solution:

- Test Hub authors and manages testcase definitions
- Test Hub exports TXT and JSON inputs into the Git worktree
- Bitbucket acts as the synchronization medium
- The DTP-CAN device pulls testcase/config content from the repository
- The device executes diagnostics on the ECU and generates output artifacts
- Output artifacts are pushed back into the repository
- Test Hub reads those artifacts and presents them to users

The architecture is modular, repository-centered, and file-driven. The device-side logic is implemented mainly in `main.py` and the `drivers/` package, while the Test Hub is implemented primarily in `server.js` plus browser-side assets in `public/`.

## 5. System Context

### 5.1 Context View

The full system sits between engineering users and the vehicle ECU network, with Bitbucket used as the operational exchange layer.

- Upstream inputs:
  - Testcase master data stored in Test Hub SQLite database
  - Exported testcase `.txt` files
  - Exported configuration `.json` files
  - Optional USB-delivered testcase/config files
  - Optional Seed-Key UDP server
- Device-side processing:
  - User selection of testcase/config
  - Diagnostic execution over CAN/CAN FD
  - Logging and report generation
- Downstream outputs:
  - ASC logs
  - HTML reports
  - Runtime logs
  - Repository update or USB export
- Hub-side post-processing:
  - Repository browsing
  - Result browsing
  - HTML report header parsing
  - Aggregated analytics

### 5.2 External Actors

- User or technician
- ECU / vehicle network
- Bitbucket repository
- Optional Test Hub or online dashboard shown in the reference illustration
- Optional external Seed-Key/UDP server
- USB storage device

### 5.3 Important Clarification

The supplied illustration’s Test Hub is implemented in the DiagTestPi application located at `T:\01_HR_Admin\11_DiagTestPi`. This application is part of the broader delivered solution even though it lives in a separate folder and technology stack from the Python device application.

## 6. Architectural Drivers

The architecture appears to be guided by the following drivers:

- Portable execution on a Raspberry Pi device
- Support for UDS diagnostics across multiple ECUs and use cases
- Field usability with simple button-based UI
- Offline and online result transfer options
- Human-readable result artifacts
- Easy testcase update through repository synchronization
- Reusability across products through config-driven behavior

## 7. High-Level Architecture

### 7.1 Logical Layers

The combined solution can be described in seven logical layers:

1. Web Presentation Layer
   - DiagTestPi browser UI
   - Testcase, Repository, Results, Analytics views

2. Device Presentation Layer
   - OLED UI
   - Button input
   - Terminal UI fallback

3. Application Control Layer
   - Main orchestration in `main.py`
   - DiagTestPi API and export/publish workflows

4. Test Management Layer
   - Testcase master database
   - Repository sync
   - Testcase discovery
   - Config loading and generation
   - USB import/export

5. Diagnostic Execution Layer
   - UDS client
   - Session handling
   - ISO-TP message transport
   - Security access support via UDP server

6. Logging and Reporting Layer
   - CAN ASC logging
   - ASC parsing
   - Testcase/result correlation
   - HTML report generation
   - Hub-side result summarization and analytics extraction

7. Platform Integration Layer
   - GPIO
   - I2C / SPI / CAN FD enablement
   - Service installation
   - SSH setup
   - Git/Bitbucket operations

### 7.2 High-Level Module View

```text
+-----------------------------------------------------------------------+
|                         DiagTestPi Test Hub                            |
| server.js + public/index.html + public/app.js + SQLite + repo_worktree|
+------------------------+-----------------------------+-----------------+
                         |                             |
                         v                             v
              +----------------------+       +---------------------------+
              | Testcase Master DB   |       | Git Worktree / Bitbucket  |
              | dtp_can_testcases    |       | Input/Testcase            |
              | import/export logic  |       | Input/JSON                |
              +----------------------+       | output/html_reports       |
                         |                   | output/can_logs           |
                         |                   +-------------+-------------+
                         |                                 |
                         |                                 v
                         |                  +-----------------------------+
                         |                  | DTP-CAN Device Application  |
                         |                  | main.py + drivers/*         |
                         |                  +-------------+---------------+
                         |                                |
                         v                                v
              +----------------------+       +---------------------------+
              | Repository/Results   |       | UDS over ISO-TP over CAN  |
              | Analytics dashboard  |       | ECU execution             |
              +----------------------+       +---------------------------+
```

## 8. Deployment Architecture

### 8.1 Hardware Deployment

The application is intended to run on a Raspberry Pi based embedded unit with:

- Raspberry Pi
- CAN adapter or CAN controller
- OLED display
- 4-button keypad
- SD card storage
- 12V power input

### 8.2 Software Deployment

The solution is deployed as two application units.

Device-side package contains:

- `main.py`
- `drivers/` package
- Config files
- `supportfiles/` for selected testcase input
- `output/` for generated artifacts
- `logs/` for runtime diagnostics

Hub-side package contains:

- `server.js`
- `public/` static frontend assets
- `database/diagtestpi.db`
- `.env`
- `repo_worktree/` mirror of repository content
- `package.json` and Node dependencies

### 8.3 Runtime Dependencies

The current implementation uses both in-house code and third-party libraries.

Device-side Python dependencies observed in the code:

- `python-can`
- `isotp`
- `udsoncan`
- `RPi.GPIO`
- `board`
- `busio`
- `adafruit_ssd1306`
- `Pillow`

Hub-side Node.js dependencies observed in `package.json`:

- `express`
- `cors`
- `express-fileupload`
- `sqlite3`
- `xlsx`

## 9. Major Software Components

### 9.0 DiagTestPi Test Hub Overview

DiagTestPi is the implemented Test Hub application used to manage DTP-CAN testcase content and repository publishing.

Its core implementation is centered in:

- `T:\01_HR_Admin\11_DiagTestPi\server.js`
- `T:\01_HR_Admin\11_DiagTestPi\public\index.html`
- `T:\01_HR_Admin\11_DiagTestPi\public\app.js`
- `T:\01_HR_Admin\11_DiagTestPi\database\diagtestpi.db`
- `T:\01_HR_Admin\11_DiagTestPi\repo_worktree`

Functional responsibilities:

- Store testcase master records in SQLite
- Provide authenticated web APIs
- Import and export Excel templates
- Export selected testcases to TXT in DTP-CAN format
- Generate JSON config payloads for the device
- Commit and push exported files to Bitbucket
- Browse repository contents and generated output artifacts
- Parse HTML report headers and build analytics

Architectural role:

- Central management console for the DTP-CAN ecosystem

### 9.1 `main.py` - Application Orchestrator

Responsibilities:

- Bootstraps the application
- Initializes hardware and user interface
- Sets up SSH and service installation
- Loads testcase and configuration
- Initializes CAN and UDS client
- Coordinates execution and result flow
- Manages UI mode selection between hardware and terminal

Architectural role:

- Central coordinator
- Entry point for all major workflows

### 9.2 `drivers/initialize_interfaces.py` - Platform Bring-Up

Responsibilities:

- Enables SPI
- Enables I2C
- Adds CAN FD overlays to Raspberry Pi boot config
- Brings up `can0`
- Triggers reboot if low-level interface setup changes

Architectural role:

- Hardware/platform bootstrap layer

### 9.3 `drivers/oled_display.py`, `drivers/button_input.py`, `drivers/terminal_ui.py`

Responsibilities:

- Display user prompts, statuses, and results
- Capture button input on hardware
- Provide terminal fallback for development or non-hardware execution

Architectural role:

- Presentation layer

Design note:

The code supports hardware, terminal, or hybrid UI modes. This improves maintainability and testability by separating interaction from core diagnostic logic.

### 9.4 `drivers/git_manager.py`

Responsibilities:

- Clone Bitbucket repository
- Pull latest changes
- Discover testcase `.txt` files
- Discover configuration `.json` files
- Copy output artifacts into repository output area
- Add, commit, and push generated artifacts

Architectural role:

- Repository integration adapter

### 9.5 `server.js` - DiagTestPi Backend

Responsibilities:

- Load environment configuration from `.env`
- Host Express APIs on configured host and port
- Enforce authentication presence for root and `/api/*` routes
- Manage SQLite access for testcase master data
- Generate testcase IDs such as `TC_ID`, `PC_ID`, and `ECU_INFO`
- Import testcase content from Excel
- Export testcase content to Excel and TXT
- Generate or include JSON configuration for device execution
- Operate on `repo_worktree` as a managed Git working copy
- Commit and push testcase/config exports to Bitbucket
- Refresh repository views safely
- Enumerate result files from generated output folders
- Parse HTML report summaries for analytics

Architectural role:

- Test Hub service layer and repository orchestration backend

### 9.6 `database/diagtestpi.db` - Testcase Master Database

Responsibilities:

- Persist testcase master rows in `dtp_can_testcases`
- Store testcase metadata such as category, type, stage, variant, service, DID/subservice, expected response, write data, addressing, format, and specification references
- Track invalidation state
- Track created/updated user and timestamp metadata

Architectural role:

- Authoritative source for Test Hub testcase master data

Important schema characteristics observed:

- Main table: `dtp_can_testcases`
- Contains lifecycle columns such as `created_by`, `updated_by`, `created_at`, `updated_at`
- Supports invalid testcase filtering through `is_invalid`
- Can be seeded from an external source database when enabled

### 9.7 `public/index.html`, `public/app.js`, `public/styles.css` - DiagTestPi Frontend

Responsibilities:

- Render browser-based operator console
- Provide four primary views:
  - Testcases
  - Repository
  - Results
  - Analytics
- Support filtering, sorting, editing, selection, export, and push workflows
- Support JSON config editing from the browser
- Show repository state and result summaries

Architectural role:

- Test Hub presentation layer

Notable implemented UI capabilities:

- Testcase search and multi-filtering
- Excel template download and import
- TXT and Excel export
- Push-to-Bitbucket modal workflow
- Repository browser and download actions
- Result listing for HTML reports and CAN logs
- Analytics filters by target ECU, S/W version, H/W version, serial number, and date range

### 9.8 `repo_worktree` - Managed Repository Mirror

Responsibilities:

- Acts as the local Git working copy used by DiagTestPi
- Stores testcase exports under `Input/Testcase`
- Stores JSON configs under `Input/JSON`
- Stores generated DTP-CAN result artifacts under `output/html_reports` and `output/can_logs`
- Provides the filesystem source for Repository and Results views

Architectural role:

- Shared repository workspace between Test Hub publishing and result consumption

### 9.9 `drivers/transfer_file.py`

Responsibilities:

- Detect mounted USB devices
- Import testcase and configuration files from USB
- Export generated output files to USB backup folders

Architectural role:

- Offline file transfer adapter

### 9.10 `drivers/config_loader.py`

Responsibilities:

- Load JSON configuration
- Provide runtime parameters for CAN, ISO-TP, GPIO, timing, addressing, and UDS settings

Architectural role:

- Configuration provider

### 9.11 `drivers/uds_client.py`

Responsibilities:

- Create CAN bus and ISO-TP connections
- Configure UDS client behavior
- Manage addressing modes
- Execute testcase steps
- Support session control, DID read/write, routine operations, security access, and related services
- Query optional UDP Seed-Key server
- Capture ECU information
- Start and stop CAN logging
- Trigger report generation after execution

Architectural role:

- Core diagnostic execution engine

Design note:

This is the most critical module in the codebase and acts as the functional core of the system.

### 9.12 `drivers/Parse_handler.py`

Responsibilities:

- Parse testcase CSV/TXT structure
- Normalize column aliases
- Group steps by testcase ID
- Preserve step order and WAIT commands

Architectural role:

- Input parsing layer for testcase definitions

### 9.13 `drivers/can_logger.py`

Responsibilities:

- Create timestamped ASC log files
- Attach `ASCWriter` to CAN bus notifier
- Start and stop capture of filtered or unfiltered CAN traffic

Architectural role:

- Raw communication logging layer

### 9.14 `drivers/report_generator.py`

Responsibilities:

- Parse ASC logs
- Reconstruct diagnostic requests and responses
- Match traffic back to testcase definitions
- Decode payloads into display-friendly values
- Build ECU information summary
- Generate HTML result reports

Architectural role:

- Result interpretation and presentation layer

### 9.15 Supporting Modules

- `drivers/did_decoder.py`
  - Contains special decoding rules for selected DIDs such as manufacturing date and B-CAN version

- `drivers/ssh_setup.py`
  - Prepares SSH access for Git connectivity

- `drivers/install_service.py`
  - Installs the application as a service for persistent device operation

## 10. Runtime Views

### 10.1 Startup Flow

```text
Application Start
  -> GPIO cleanup
  -> Hardware interface initialization
  -> SPI / I2C / CAN FD enablement
  -> UI initialization
  -> Wi-Fi and connectivity preparation
  -> SSH setup
  -> Git repository clone/pull
  -> Testcase selection
  -> Config selection
  -> UDS client creation
  -> UDP server availability check
  -> CAN interface bring-up
  -> Ready for execution
```

### 10.2 Testcase Execution Flow

```text
User selects testcase and config
  -> Testcase copied to supportfiles
  -> Configuration loaded
  -> UDS client starts CAN logging
  -> Testcase file parsed into grouped steps
  -> Each step executed over ISO-TP/UDS
  -> ECU responses collected and validated
  -> Runtime status shown on UI
  -> CAN log finalized
  -> HTML report generated from ASC + testcase definition
  -> Outputs stored locally
  -> Outputs can be pushed to repo or copied to USB
```

### 10.3 Security Access Flow

The code indicates a hybrid security-access model:

- Seed may be requested from ECU via UDS
- Key generation may be delegated to an external UDP server
- The application checks server availability during startup
- If the server is unavailable, startup continues with degraded capability

This is a pragmatic architecture for controlled environments where seed-key logic is intentionally externalized.

### 10.4 Test Hub Publish Flow

```text
User opens DiagTestPi
  -> Browser loads Testcases / Repository / Results / Analytics UI
  -> User creates, edits, imports, or filters testcase master data
  -> Selected testcase rows are expanded with dependencies such as PC_ID rows
  -> Hub exports TXT content in DTP-CAN testcase format
  -> Optional JSON config content is generated or edited in UI
  -> Hub syncs repo_worktree with Bitbucket
  -> Hub writes TXT/JSON into repo_worktree
  -> Hub stages, commits, and pushes to origin/main
```

### 10.5 Test Hub Result Consumption Flow

```text
DTP-CAN device pushes ASC and HTML artifacts into repository output folders
  -> DiagTestPi refreshes repo_worktree from Bitbucket
  -> Results view lists HTML reports and CAN logs from repo_worktree/output
  -> Analytics flow parses HTML report header fields
  -> Hub derives metrics such as total, passed, failed, target ECU, S/W version, H/W version, and ECU serial number
  -> User filters and reviews execution history in the browser
```

## 11. Data Architecture

### 11.1 Input Artifacts

- Testcase master rows in SQLite
- Exported testcase definition files: `.txt`
- Exported or uploaded configuration files: `.json`
- Imported testcase spreadsheets: `.xlsx`
- Optional USB-delivered testcase/config copies

### 11.2 Intermediate Runtime Data

- Parsed testcase groups
- UDS request/response buffers
- ECU information dictionary
- Current session and addressing context
- Button and menu state

### 11.3 Output Artifacts

- ASC logs in `output/can_logs`
- HTML reports in `output/html_reports`
- Runtime logs in `logs` or `output/logs`
- Testcase export spreadsheets
- Testcase export TXT files
- JSON config files
- Copied or synchronized repository output

### 11.4 Data Ownership

- Test Hub SQLite database is the authoritative source for testcase master data
- Exported testcase TXT file is the authoritative packaged execution input for the device
- Config JSON file is the authoritative definition of transport/runtime behavior for a selected run
- ASC file is the authoritative raw execution trace
- HTML report is the derived human-readable execution artifact

## 12. Communication Architecture

### 12.1 In-Vehicle Communication

- Protocol family: UDS over ISO-TP over CAN/CAN FD
- Transport implementation: `isotp`
- UDS client implementation: `udsoncan`
- CAN access: `python-can`

### 12.2 External Connectivity

- Git over SSH to Bitbucket
- UDP to external Seed-Key service
- USB mass storage for offline import/export
- Browser access to DiagTestPi over HTTP

### 12.3 Addressing Support

The code supports:

- Physical addressing
- Functional addressing
- Config-driven TX/RX identifiers
- 11-bit and 29-bit operation depending on configuration

## 13. Configuration Architecture

The solution is configuration-driven on both the device side and hub side.

Device-side JSON configuration influences:

- CAN channel and interface
- Bitrate and data bitrate
- ISO-TP timing and frame settings
- UDS session timing
- Addressing mode IDs
- GPIO button mapping
- Menu combinations
- DID decoding definitions
- ECU information DID mapping
- Write data definitions
- Logging behavior

Hub-side `.env` configuration influences:

- Web server host and port
- SQLite database path
- Source database seed path
- Timesheet/user lookup database path
- Bitbucket workspace, repo, branch, and remote name
- Git worktree path
- Git safe-directory handling
- SSH command override for Git
- Login redirect URL

DiagTestPi also contains a browser-side JSON config editor that produces DTP-CAN compatible configuration files with default menu and file-transfer sections merged in.

This design improves reusability across ECU variants and products without requiring code modification for every change.

## 14. Error Handling and Resilience

Observed resilience mechanisms include:

- Terminal UI fallback when hardware UI is unavailable
- Startup retry for UDP server reachability
- Continue-startup behavior when UDP server is unavailable
- CAN interface bring-up retry path in application flow
- Log-based post-processing even after communication issues
- HTML report generation from raw ASC trace
- USB transfer fallback for result retrieval
- DiagTestPi Git safe-directory handling
- Hub-side repository blocker detection for merge/rebase/conflict states
- Hub-side temporary stash and restore during sync/refresh flows
- Local repository view fallback when remote refresh is blocked or unavailable

Limitations observed in the current implementation:

- Strong reliance on filesystem and repository layout
- Several responsibilities are concentrated in `main.py` and `uds_client.py`
- Error handling is largely operational rather than policy-driven
- Some behaviors depend on environment assumptions typical of Raspberry Pi deployments

## 15. Key Architectural Strengths

- Clear modular separation between UI, transport, logging, and reporting
- Strong use of configuration to support reuse
- Supports both online and offline operational models
- Good alignment with field-diagnostics workflow
- Raw trace preservation through ASC logs improves diagnosability
- Report generation from communication traces provides post-run traceability

## 16. Architectural Risks and Improvement Opportunities

### 16.1 Current Risks

- `main.py` acts as a large coordinator and may grow difficult to maintain
- `uds_client.py` combines connection setup, execution, security access, logging, and reporting triggers
- Repository operations are tightly coupled to runtime flow
- Limited explicit domain model for testcase, step, response, and report entities
- Large monolithic `server.js` file in DiagTestPi
- Tight coupling between filesystem layout, repo_worktree layout, and UI assumptions

### 16.2 Recommended Improvements

1. Introduce an application service layer
   - Separate workflow orchestration from UI and hardware concerns

2. Introduce explicit domain models
   - `Testcase`, `TestStep`, `ExecutionResult`, `ECUInfo`, `ReportArtifact`

3. Isolate repository integration behind a formal interface
   - Make Git/Bitbucket replaceable by another backend if needed

4. Split `uds_client.py`
   - Connection manager
   - Diagnostic executor
   - Security access adapter
   - ECU info collector
   - Execution coordinator

5. Add structured event logging
   - Helpful for field debugging and future analytics integration

6. Define a stable output contract
   - Especially because DiagTestPi consumes repository outputs automatically

7. Split `server.js`
   - Separate API routes, database access, Git service, export service, result parser, and analytics service

8. Add a formal shared contract between Test Hub and DTP-CAN
   - Testcase TXT format
   - Config JSON format
   - Result folder structure
   - HTML header fields used for analytics

## 17. DiagTestPi API and Data Capabilities

Based on the current implementation, DiagTestPi exposes the following major backend capabilities:

- Session lookup:
  - `/api/session`

- Testcase master CRUD and selection:
  - `/api/dtp-can`
  - `/api/dtp-can/:id`
  - `/api/dtp-can/selection`

- Excel import/export:
  - `/api/dtp-can/template.xlsx`
  - `/api/dtp-can/import.xlsx`
  - `/api/dtp-can/export.xlsx`

- TXT export and Git publishing:
  - `/api/dtp-can/export.txt`
  - `/api/dtp-can/push-git`

- Repository browser:
  - `/api/git-view/contents`
  - `/api/git-view/download`

- Results and analytics:
  - `/api/results`
  - `/api/results/download`
  - `/api/analytics`

These APIs make DiagTestPi not just a testcase editor, but the operational control plane for testcase publishing and result consumption.

## 18. Mapping to the Reference Illustration

The supplied illustration aligns well with the implemented code at a conceptual level:

- Hardware/device side maps to Raspberry Pi, CAN, display, keypad, storage, and power modules
- Connectivity/data flow maps to Git/Bitbucket synchronization and external service access
- Test Hub maps directly to the implemented DiagTestPi application
- Execution flow maps to testcase authoring, testcase push, ECU execution, result generation, result push, and result visualization
- Benefits map closely to the current design intent

## 19. Conclusion

The DTP-CAN solution is a two-tier architecture:

- A Python-based embedded diagnostic executor on the DTP-CAN hardware unit
- A Node.js-based DiagTestPi Test Hub for testcase management, repository publishing, and result analytics

Its strongest qualities are config-driven behavior, repository-based exchange, support for UDS over CAN/CAN FD, and an end-to-end feedback loop from testcase authoring to ECU execution to analytics consumption.

The architecture is well suited for engineering labs, validation teams, and controlled field workflows. The most valuable next step will be service decomposition on both sides, especially in `uds_client.py` and `server.js`, so the system remains maintainable as feature scope grows.
