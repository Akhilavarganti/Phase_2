import os
import zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape


ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUTPUT_PATH = os.path.join(ROOT_DIR, "DTP_CAN_Detailed_Design_Document.docx")


def paragraph_xml(text, style=None):
    parts = text.split("\n")
    runs = []
    for idx, part in enumerate(parts):
        safe_part = escape(part)
        runs.append(f"<w:r><w:t xml:space=\"preserve\">{safe_part}</w:t></w:r>")
        if idx < len(parts) - 1:
            runs.append("<w:r><w:br/></w:r>")

    style_xml = f"<w:pPr><w:pStyle w:val=\"{style}\"/></w:pPr>" if style else ""
    return f"<w:p>{style_xml}{''.join(runs)}</w:p>"


def build_document_xml(paragraphs):
    body = [paragraph_xml(text, style=style) for style, text in paragraphs]
    body.append(
        "<w:sectPr>"
        "<w:pgSz w:w=\"12240\" w:h=\"15840\"/>"
        "<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" "
        "w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/>"
        "</w:sectPr>"
    )
    return (
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        "<w:document xmlns:wpc=\"http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas\" "
        "xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" "
        "xmlns:o=\"urn:schemas-microsoft-com:office:office\" "
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
        "xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" "
        "xmlns:v=\"urn:schemas-microsoft-com:vml\" "
        "xmlns:wp14=\"http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing\" "
        "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" "
        "xmlns:w10=\"urn:schemas-microsoft-com:office:word\" "
        "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
        "xmlns:w14=\"http://schemas.microsoft.com/office/word/2010/wordml\" "
        "xmlns:wpg=\"http://schemas.microsoft.com/office/word/2010/wordprocessingGroup\" "
        "xmlns:wpi=\"http://schemas.microsoft.com/office/word/2010/wordprocessingInk\" "
        "xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" "
        "xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\" "
        "mc:Ignorable=\"w14 wp14\">"
        "<w:body>"
        f"{''.join(body)}"
        "</w:body>"
        "</w:document>"
    )


def build_styles_xml():
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:qFormat/>
    <w:rPr>
      <w:sz w:val="22"/>
      <w:szCs w:val="22"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:rPr>
      <w:b/>
      <w:sz w:val="32"/>
      <w:szCs w:val="32"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:rPr>
      <w:b/>
      <w:sz w:val="28"/>
      <w:szCs w:val="28"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:rPr>
      <w:b/>
      <w:sz w:val="24"/>
      <w:szCs w:val="24"/>
    </w:rPr>
  </w:style>
</w:styles>
"""


def build_content_types_xml():
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>
"""


def build_root_rels_xml():
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>
"""


def build_document_rels_xml():
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>
"""


def build_core_xml():
    created = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:dcterms="http://purl.org/dc/terms/"
 xmlns:dcmitype="http://purl.org/dc/dcmitype/"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>DTP CAN Detailed Design Document</dc:title>
  <dc:creator>OpenAI Codex</dc:creator>
  <cp:lastModifiedBy>OpenAI Codex</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified>
</cp:coreProperties>
"""


def build_app_xml():
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
 xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>OpenAI Codex</Application>
</Properties>
"""


def bullets(*items):
    return [(None, f"- {item}") for item in items]


def build_paragraphs():
    paragraphs = [
        ("Title", "DTP CAN Detailed Design Document"),
        (None, "Generated on: July 20, 2026"),
        (None, "Project root: D:\\temp\\DTP-CAN\\DTP_code"),

        ("Heading1", "1. Purpose"),
        *bullets(
            "Describe the detailed design of the DTP CAN Raspberry Pi diagnostics application.",
            "Cover startup flow, UI flow, WiFi provisioning, testcase/config handling, CAN/UDS flow, reporting, USB transfer, and Bitbucket operations.",
        ),

        ("Heading1", "2. System Overview"),
        *bullets(
            "Application entry point: main.py",
            "Main orchestration class: UDSApp",
            "Primary platform: Raspberry Pi",
            "Main subsystems: UI, hardware initialization, WiFi, Git/Bitbucket, testcase/config loading, UDS over CAN FD, report generation, USB transfer",
            "Runtime modes: hardware mode, terminal mode, hybrid mode",
            "Hybrid mode behavior: mirror display updates to OLED and monitor, accept input from keypad and keyboard",
        ),

        ("Heading1", "3. Repository Structure"),
        *bullets(
            "main.py: top-level control flow",
            "drivers/initialize_interfaces.py: SPI, I2C, CAN FD setup",
            "drivers/oled_display.py: SSD1306 display rendering",
            "drivers/button_input.py: GPIO keypad polling",
            "drivers/terminal_ui.py: terminal mirroring and keyboard polling",
            "drivers/config_loader.py: JSON configuration loading",
            "drivers/Parse_handler.py: testcase parsing and grouping",
            "drivers/uds_client.py: UDS execution logic",
            "drivers/can_logger.py: ASC CAN logging",
            "drivers/report_generator.py: HTML report generation",
            "drivers/transfer_file.py: USB import/export",
            "drivers/git_manager.py: clone, pull, add, commit, push",
            "drivers/ssh_setup.py: SSH agent and key provisioning",
            "build_on_pi.sh: Raspberry Pi packaging flow",
        ),

        ("Heading1", "4. Runtime Lifecycle"),
        ("Heading2", "4.1 Entry Point"),
        *bullets(
            "main() creates UDSApp.",
            "UDSApp constructor initializes dependencies.",
            "After initialization, main_menu() starts the operator workflow.",
        ),
        ("Heading2", "4.2 Startup Sequence"),
        *bullets(
            "1. Clean up GPIO state.",
            "2. Initialize Raspberry Pi interfaces.",
            "3. Prepare SSH for Git access.",
            "4. Initialize OLED, keypad, terminal UI, or both.",
            "5. Run WiFi setup.",
            "6. Start WiFi monitor thread.",
            "7. Clone/pull the Bitbucket repository.",
            "8. Select testcase TXT file.",
            "9. Select config JSON file.",
            "10. Load JSON configuration.",
            "11. Create UDSClient.",
            "12. Check UDP seed-key server.",
            "13. Read CAN timing settings.",
            "14. Optionally validate CAN and ECU connectivity.",
            "15. Create USB transfer helper.",
            "16. Enter main menu.",
        ),

        ("Heading1", "5. User Interface Design"),
        ("Heading2", "5.1 Hardware UI"),
        *bullets(
            "Display device: 128x64 SSD1306 OLED on I2C.",
            "Input device: 4-button keypad on GPIO BCM pins.",
            "Display behavior: centered text plus WiFi status marker.",
            "Input behavior: nonblocking button polling.",
        ),
        ("Heading2", "5.2 Terminal UI"),
        *bullets(
            "Display device: Linux terminal / monitor output.",
            "Input device: attached keyboard.",
            "Keyboard handling: cbreak mode with single-key polling.",
            "Terminal redraw: stateful redraw to avoid repeated printing.",
        ),
        ("Heading2", "5.3 Hybrid UI"),
        *bullets(
            "DisplayRouter sends the same message to OLED and terminal.",
            "Selection loops poll keypad and keyboard in parallel.",
            "Either input path can complete WiFi, testcase, config, and menu selection.",
        ),
        ("Heading2", "5.4 Selection Controls"),
        *bullets(
            "Keypad: previous, next, enter, cancel/power.",
            "Keyboard: A/P previous, D/N next, S or Enter select, Q or Esc cancel.",
            "Keyboard direct selection: digits 1-9 where applicable.",
        ),

        ("Heading1", "6. Hardware and Platform Initialization"),
        ("Heading2", "6.1 SPI, I2C and CAN FD Configuration"),
        *bullets(
            "Boot configuration file used: /boot/firmware/config.txt",
            "SPI check: /dev/spidev0.0",
            "I2C check: /dev/i2c-1",
            "CAN FD overlay check: grep for mcp251xfd",
            "Missing settings are appended with sudo tee.",
            "CAN FD overlay lines added when required: spi enable, spi0-0 overlay, spi1-0 overlay",
        ),
        ("Heading2", "6.2 Reboot Behavior"),
        *bullets(
            "If boot config changes are made, reboot_required is set.",
            "When reboot_required is true, the helper triggers sudo reboot.",
            "When no reboot is required, initialization continues directly.",
        ),
        ("Heading2", "6.3 CAN Bring-up"),
        *bullets(
            "Checks whether can0 exists.",
            "Checks whether can0 is already UP.",
            "Runs ip and ifconfig commands to bring can0 online.",
            "main.py can later reconfigure bitrate, dbitrate, restart-ms, and berr-reporting using JSON config values.",
        ),

        ("Heading1", "7. WiFi Design"),
        ("Heading2", "7.1 Scan and Selection"),
        *bullets(
            "Command used: nmcli -t -f SSID dev wifi",
            "SSID list is de-duplicated before presentation.",
            "Selection is performed through the shared list-selection loop.",
        ),
        ("Heading2", "7.2 Saved Connection Handling"),
        *bullets(
            "Check whether the SSID exists in saved nmcli connections.",
            "If already connected, reuse the active connection.",
            "If saved but inactive, try nmcli connection up <ssid>.",
            "If saved connection fails, delete it and request password again.",
        ),
        ("Heading2", "7.3 New Connection Handling"),
        *bullets(
            "Prompt the operator for the WiFi password.",
            "Run nmcli --wait 15 device wifi connect <ssid> password <password>.",
            "On success, set current_ssid and WiFi state W+.",
        ),
        ("Heading2", "7.4 Password Entry"),
        *bullets(
            "Keypad path: character-by-character password entry.",
            "Keyboard path: direct typing with Backspace and Enter support.",
            "Hybrid mode: keypad and keyboard remain active together.",
        ),
        ("Heading2", "7.5 Background Monitoring"),
        *bullets(
            "WiFi monitor runs in a daemon thread.",
            "Polling interval: 10 seconds.",
            "On disconnect, the UI shows reconnect status.",
            "Reconnect method: nmcli connection up <last_ssid>.",
        ),

        ("Heading1", "8. Repository and Configuration Flow"),
        ("Heading2", "8.1 Repository Clone and Pull"),
        *bullets(
            "Repository URL: git@bitbucket.org:mobase-rnd/dtp-can.git",
            "Target branch: main",
            "Clone happens if the local repo directory does not exist.",
            "Pull command: git -C <repo_path> pull origin main",
        ),
        ("Heading2", "8.2 Testcase Discovery"),
        *bullets(
            "GitManager scans the cloned repository recursively.",
            "All .txt files are treated as testcase candidates.",
            "Selected testcase is copied into supportfiles.",
            "Selected testcase basename is written into selected_testcase.txt.",
        ),
        ("Heading2", "8.3 Configuration Discovery"),
        *bullets(
            "GitManager scans the cloned repository recursively.",
            "All .json files are treated as configuration candidates.",
            "Selected JSON path is forwarded to config_loader.load_config().",
        ),
        ("Heading2", "8.4 Config Loader"),
        *bullets(
            "Relative paths are resolved against the configured base path.",
            "Missing files raise FileNotFoundError.",
            "Invalid JSON raises an explicit format error.",
            "Loaded config drives UDS, CAN, timing, GPIO, and menu behavior.",
        ),

        ("Heading1", "9. Testcase Parsing Design"),
        *bullets(
            "The third row of the testcase file is treated as the effective header.",
            "HEADER_ALIASES maps multiple header names to the same logical field.",
            "Rows are grouped by TC_ID.",
            "WAIT rows are converted into ('WAIT', milliseconds).",
            "Normal rows are converted into tuples containing service, DID/subfunction, expected response, write data, addressing, format, and control fields.",
        ),

        ("Heading1", "10. UDS Communication Design"),
        ("Heading2", "10.1 UDSClient Construction"),
        *bullets(
            "Read timing, CAN, and ISO-TP configuration from JSON.",
            "Build data identifier decoders using SafeAsciiCodec.",
            "Create physical and optional functional addressing definitions.",
            "Create python-can buses and ISO-TP connection objects.",
            "Create CAN logger with configured filters.",
        ),
        ("Heading2", "10.2 Addressing Modes"),
        *bullets(
            "Default active mode: physical",
            "Functional mode is supported when defined in config.",
            "switch_mode() changes the active addressing path per testcase step.",
        ),
        ("Heading2", "10.3 UDP Seed-Key Server Check"),
        *bullets(
            "Send a test UDP payload to the configured seed-key server.",
            "Wait for response with socket timeout handling.",
            "If a response is received, mark the server as available.",
            "If not, log the timeout/error and continue startup.",
        ),
        ("Heading2", "10.4 ECU Information Read"),
        *bullets(
            "Load grouped testcase definitions.",
            "Open a UDS client session.",
            "Change to default session, then extended session.",
            "Process only testcase IDs that start with ECU_INFO.",
            "Build raw requests, send them, validate responses, and decode values.",
            "Store printable ASCII where applicable, otherwise store hexadecimal.",
        ),
        ("Heading2", "10.5 Testcase Execution"),
        *bullets(
            "Check free space / memory constraints before execution.",
            "Read ECU information first for report context.",
            "Start CAN ASC logging.",
            "Reload grouped testcase definitions.",
            "Honor WAIT steps as millisecond delays.",
            "Switch addressing mode per step.",
            "Send raw UDS requests and collect responses.",
            "Evaluate pass/fail using expected response comparison.",
            "Generate final report output after testcase execution.",
        ),
        ("Heading2", "10.6 Connection Validation"),
        *bullets(
            "Used when bringup_on_startup is enabled in the JSON config.",
            "Check for can0 presence within the timeout window.",
            "Bring up CAN interface.",
            "Create a temporary UDS client.",
            "Run try_basic_communication() against the ECU.",
            "Abort initialization if no ECU response is received in time.",
        ),

        ("Heading1", "11. CAN Logging and Output Generation"),
        ("Heading2", "11.1 ASC CAN Logging"),
        *bullets(
            "ASC logs are written into output/can_logs.",
            "Logger uses python-can Notifier and ASCWriter.",
            "Filters can be enabled to limit logs to physical and functional UDS IDs.",
        ),
        ("Heading2", "11.2 Output Folders"),
        *bullets(
            "Ensures output/can_logs exists.",
            "Ensures output/html_reports exists.",
            "Ensures output/logs exists.",
            "Ensures supportfiles exists.",
            "Application debug log path: logs/uds_debug.log",
        ),
        ("Heading2", "11.3 HTML Report Generation"),
        *bullets(
            "Parses the CAN ASC log and reconstructs testcase events.",
            "Builds summary information: pass count, fail count, duration, author, generated files.",
            "Builds ECU information summary section.",
            "Builds per-testcase collapsible tables with requests, expected data, responses, and failure reasons.",
            "Loads Chart.js from CDN for pass/fail visualization.",
        ),

        ("Heading1", "12. USB Transfer Design"),
        ("Heading2", "12.1 Import from USB"),
        *bullets(
            "Search mounted devices under /media.",
            "Scan the USB recursively for .txt and .json files.",
            "Copy testcase TXT files into supportfiles.",
            "Write selected_testcase.txt with the chosen testcase name.",
            "Copy JSON files into the application base directory.",
            "Skip git_credentials.json during import.",
        ),
        ("Heading2", "12.2 Export to USB"),
        *bullets(
            "Create a timestamped backup directory on the USB device.",
            "Copy the local output directory into an Outputs folder inside that backup.",
            "Show progress animation and final file count.",
        ),

        ("Heading1", "13. Bitbucket and SSH Design"),
        ("Heading2", "13.1 SSH Provisioning"),
        *bullets(
            "Check whether OpenSSH tools are installed.",
            "Start ssh-agent if SSH_AUTH_SOCK is missing.",
            "Write the private key into ~/.ssh/diagtestpi_bitbucket if absent.",
            "Write the matching public key if absent.",
            "Add the private key to ssh-agent using ssh-add.",
        ),
        ("Heading2", "13.2 Clone Operation"),
        *bullets(
            "Method: GitManager.clone_repository()",
            "Condition: run only if the local repo folder does not exist",
            "Command: git clone git@bitbucket.org:mobase-rnd/dtp-can.git <repo_path>",
        ),
        ("Heading2", "13.3 Pull Operation"),
        *bullets(
            "Method: GitManager.pull_repository()",
            "Command: git -C <repo_path> pull origin main",
            "Purpose: refresh the local testcase/config repository before operator selection",
        ),
        ("Heading2", "13.4 Commit and Push Operation from Menu Option 4"),
        *bullets(
            "Step 1: main.py shows Uploading Reports to Bitbucket.",
            "Step 2: copy_reports() copies <base_dir>/output to <repo_path>/output.",
            "Step 3: git_add() runs git -C <repo_path> add .",
            "Step 4: git_commit() runs git -C <repo_path> commit -m \"Updated Reports\".",
            "Step 5: git_push() runs git -C <repo_path> push origin main.",
        ),
        ("Heading2", "13.5 Current Implementation Quirk"),
        *bullets(
            "git_push() currently executes the same push command twice.",
            "The second push is redundant if the first push succeeds.",
        ),
        ("Heading2", "13.6 Error Handling"),
        *bullets(
            "Any GitManager exception in menu option 4 is caught by main.py.",
            "Failure UI message: Bitbucket Push Failed",
            "Success UI message: Upload Complete",
        ),

        ("Heading1", "14. Main Menu Behavior"),
        *bullets(
            "Menu option 1: ECU Information",
            "Menu option 2: Run Test Cases",
            "Menu option 3: Shut Down",
            "Menu option 4: Push to Bitbucket",
            "Keypad selection remains active.",
            "Keyboard digit selection 1-4 is also supported.",
        ),

        ("Heading1", "15. Build and Deployment Design"),
        *bullets(
            "build_on_pi.sh creates a Python virtual environment.",
            "Installs Raspberry Pi, UDS, CAN, and packaging dependencies.",
            "Packages the app using PyInstaller into uds_diagnostics.",
            "Adds hidden imports for board, RPi.GPIO, adafruit, Pillow, can, isotp, udsoncan, and drivers modules.",
            "Creates dist/output and dist/supportfiles directories for runtime data.",
        ),

        ("Heading1", "16. Important Assumptions and Risks"),
        *bullets(
            "The application is Linux and Raspberry Pi specific.",
            "WiFi management depends on NetworkManager and nmcli.",
            "CAN communication depends on socketcan-compatible interface naming.",
            "HTML report chart rendering depends on internet access to load Chart.js CDN.",
            "SSH private key material is embedded in source code.",
            "Git push is duplicated in the current implementation.",
            "file_transfer_menu() is still keypad-driven.",
            "Several steps require sudo-capable shell access.",
        ),

        ("Heading1", "17. Recommended Enhancements"),
        *bullets(
            "Move SSH key provisioning out of source code.",
            "Remove the duplicate git push call.",
            "Show detailed git stderr/stdout when repository actions fail.",
            "Extend USB file-transfer menu to terminal keyboard flow.",
            "Add structured configuration validation before ECU communication.",
            "Add tests for config loading and testcase parsing.",
            "Further decouple startup diagnostics for Git, WiFi, CAN, and ECU readiness.",
        ),

        ("Heading1", "18. Summary"),
        *bullets(
            "The application combines local UI, Raspberry Pi hardware setup, WiFi setup, repository-driven testcase/config handling, UDS communication, CAN logging, HTML reporting, USB transfer, and Bitbucket upload.",
            "Main orchestration is centralized in UDSApp.",
            "Specialized driver modules handle the hardware, communication, storage, and Git responsibilities.",
        ),
    ]
    return paragraphs


def write_docx(output_path, paragraphs):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", build_content_types_xml())
        zf.writestr("_rels/.rels", build_root_rels_xml())
        zf.writestr("docProps/core.xml", build_core_xml())
        zf.writestr("docProps/app.xml", build_app_xml())
        zf.writestr("word/document.xml", build_document_xml(paragraphs))
        zf.writestr("word/styles.xml", build_styles_xml())
        zf.writestr("word/_rels/document.xml.rels", build_document_rels_xml())


def main():
    write_docx(OUTPUT_PATH, build_paragraphs())
    print(OUTPUT_PATH)


if __name__ == "__main__":
    main()
