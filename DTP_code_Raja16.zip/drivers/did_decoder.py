def _normalize_desc(desc):
    return (
        (desc or "")
        .strip()
        .lower()
        .replace("_", " ")
        .replace("-", " ")
    )


def _normalize_hex_bytes(payload):
    normalized = []
    for byte in payload or []:
        if isinstance(byte, int):
            normalized.append(f"{byte:02X}")
        elif isinstance(byte, str):
            normalized.append(byte.strip().upper())
    return [byte for byte in normalized if byte]


def _parse_bcd_byte(byte_str):
    if len(byte_str) != 2:
        return None

    try:
        high = int(byte_str[0], 16)
        low = int(byte_str[1], 16)
    except ValueError:
        return None

    if high > 9 or low > 9:
        return None

    return (high * 10) + low


def decode_special_did_value(desc, payload):
    normalized_desc = _normalize_desc(desc)
    clean_payload = _normalize_hex_bytes(payload)

    if not clean_payload:
        return None

    if "b can" in normalized_desc and "version" in normalized_desc:
        # Keep the hex-digit/Bcd representation unchanged and add dots.
        return ".".join(clean_payload[:3]) if len(clean_payload) >= 3 else None

    if "manufacturing date" in normalized_desc:
        if len(clean_payload) < 4:
            return ""

        year_hi = _parse_bcd_byte(clean_payload[0])
        year_lo = _parse_bcd_byte(clean_payload[1])
        month = _parse_bcd_byte(clean_payload[2])
        day = _parse_bcd_byte(clean_payload[3])

        if None in (year_hi, year_lo, month, day):
            return ""

        if month < 1 or month > 12 or day < 1 or day > 31:
            return ""

        year = f"{year_hi:02d}{year_lo:02d}"
        return f"{year}-{month:02d}-{day:02d}"

    return None
